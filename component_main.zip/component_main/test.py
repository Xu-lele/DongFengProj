import os
p_path = os.path.abspath(os.path.dirname(__file__))
print(p_path)


ctrl_miss_path = os.path.abspath(os.path.join(os.path.abspath(os.path.dirname(__file__)), "../../pathGenerate/ctrl_mission_planning"))
